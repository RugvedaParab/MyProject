<html>
	<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>    
	
	</head>
	
	<body>
	
		<div class="navbar navbar-inverse navbar-fixed-top">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynav">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><b>Lifestyle Store</a>
             </div>
            <ul class="nav navbar-nav navbar-right collapse navbar-collapse" value="mynav">
                
                <li><a href="cart.html"><span class="glyphicon glyphicon-shopping-cart"></span><b>Cart</b></a></li>
                <li><a href="settings.html"><span class="glyphicon glyphicon-user"></span><b>Settings</b></a></li>
                <li><a href="logout.html"><span class="glyphicon glyphicon-log-in"></span><b>Logout</b></a></li>
                
                <li><a href="index.html"><span class="glyphicon glyphicon-home"></span><b>Home</b></a></li>
                <li><a href="signup.html"><span class="glyphicon glyphicon-user"></span><b>Signup</b></a></li>
                <li><a href="login.html"><span class="glyphicon glyphicon-log-in"></span><b>Login</b></a></li>
            
            </ul>            
        </div>
		
	
	</body>
	
</html>