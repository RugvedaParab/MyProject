<?php 
include 'Common.php';?>
<html>
    <head>
        <title>Products Page</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="product.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>    
    </head>

    <body>

        <?php include 'header.php';
               ?>
        <div class="container">
            <div class="jumbotron" >
                <h1>Welcome to our lifestyle store</h1>
                <p>“We have the best cameras, watches and shirts for you. No need to hunt around, we have all in one place.”</p>
            </div>

        </div>

        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="camera.jpg" alt="Camera"> 
                    <div class="caption">
                        <center>
                            <h4><b>Cannon EOS</b></h4>
                            <p>Price Rs 36000</p>
                            <button class="btn btn-primary">Add to Cart</button>
                        </center>
                    </div>
                
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                        <img src="sony.jpg" alt="Camera"> 
                        <div class="caption">
                            <center>
                                <h4><b>Sony DSLR</b></h4>
                                <p>Price Rs 40000</p>
                                <button class="btn btn-primary">Add to Cart</button>
                            </center>
                        </div>
                    
                    </div>
            </div>
            
            <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                        <img src="sony1.jpg" alt="Camera"> 
                        <div class="caption">
                            <center>
                                <h4><b>Sony DSLR</b></h4>
                                <p>Price Rs 50000</p>
                                <button class="btn btn-primary">Add to Cart</button>
                            </center>
                        </div>
                    
                    </div>
            </div>

            <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                        <img src="oly.jpg" alt="Camera"> 
                        <div class="caption">
                            <center>
                                <h4><b>Olympus DSLR</b></h4>
                                <p>Price Rs 80000</p>
                                <button class="btn btn-primary">Add to Cart</button>
                            </center>
                        </div>
                    
                    </div>
            </div>
        </div>
       <!--Watches-->
        <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                        <img src="t1.jpg" alt="Camera"> 
                        <div class="caption">
                            <center>
                                <h4><b>Titan Model #301</b></h4>
                                <p>Price Rs 18000</p>
                                <button class="btn btn-primary">Add to Cart</button>
                            </center>
                        </div>
                    
                    </div>
                </div>
    
                <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            <img src="t2.jpg" alt="Camera"> 
                            <div class="caption">
                                <center>
                                    <h4><b>Titan Model #201</b></h4>
                                    <p>Price Rs 8000</p>
                                    <button class="btn btn-primary">Add to Cart</button>
                                </center>
                            </div>
                        
                        </div>
                </div>
    
                <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            <img src="t3.jpg" alt="Camera"> 
                            <div class="caption">
                                <center>
                                    <h4><b>Titan Edge</b></h4>
                                    <p>Price Rs 10000</p>
                                    <button class="btn btn-primary">Add to Cart</button>
                                </center>
                            </div>
                        
                        </div>
                </div>
    
                <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            <img src="t4.jpg" alt="Camera"> 
                            <div class="caption">
                                <center>
                                    <h4><b>Titan New</b></h4>
                                    <p>Price Rs 20000</p>
                                    <button class="btn btn-primary">Add to Cart</button>
                                </center>
                            </div>
                        
                        </div>
                </div>
        </div>
        
            <!--Shirts-->
            <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            <img src="s1.jpg" alt="Camera"> 
                            <div class="caption">
                                <center>
                                    <h4><b>Park Avenue</b></h4>
                                    <p>Price Rs 2000</p>
                                    <button class="btn btn-primary">Add to Cart</button>
                                </center>
                            </div>
                        
                        </div>
                    </div>
        
                    <div class="col-md-3 col-sm-6">
                            <div class="thumbnail">
                                <img src="s2.jpg" alt="Camera"> 
                                <div class="caption">
                                    <center>
                                        <h4><b>Luis Phil</b></h4>
                                        <p>Price Rs 1000</p>
                                        <button class="btn btn-primary">Add to Cart</button>
                                    </center>
                                </div>
                            
                            </div>
                    </div>
        
                    <div class="col-md-3 col-sm-6">
                            <div class="thumbnail">
                                <img src="s3.jpg" alt="Camera"> 
                                <div class="caption">
                                    <center>
                                        <h4><b>John Zok</b></h4>
                                        <p>Price Rs 1500</p>
                                        <button class="btn btn-primary">Add to Cart</button>
                                    </center>
                                </div>
                            
                            </div>
                    </div>
        
                    <div class="col-md-3 col-sm-6">
                            <div class="thumbnail">
                                <img src="s4.jpg" alt="Camera"> 
                                <div class="caption">
                                    <center>
                                        <h4><b>H & W</b></h4>
                                        <p>Price Rs 800</p>
                                        <button class="btn btn-primary">Add to Cart</button>
                                    </center>
                                </div>
                            
                            </div>
                    </div>
            </div>
            
            
    <?php include 'footer.php';?>    
    </body>
</html> 