<?php
session_start();
$email="";
$passwd="";

$con=mysqli_connect("localhost","root"," ","eCom");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


?>