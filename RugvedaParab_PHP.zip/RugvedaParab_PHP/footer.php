
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>    
	<style>
	footer{
    padding: 10px 0;
    background-color: black;
    color:white;
    bottom: 0;
    width:100%;
    position: fixed;
    }
	
	</style>
</head>

<body>
<footer>
		<div class="container-fluid">
	<center>
		<p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 90000
00000</p>
	</center>

		</div>
</footer>
</body>

</html>
