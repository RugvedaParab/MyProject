<?php
include 'Common.php';

if(isset($_POST['login']))
{    
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $passwd = mysqli_real_escape_string($con, $_POST['passwd']);
}

$select_query="select id,email from users";
$select_query_result=mysqli_query($con, $select_query) or die(mysqli_errno($con));

$row=mysqli_fetch_array($select_query_result);
echo $row['id'];
echo $row['email'];

$_SESSION['id']=mysqli_insert_id($con);
$_SESSION['email']=$email;

if (isset($_SESSION['email'])) {
    header('location: Products.php');
}
?>
