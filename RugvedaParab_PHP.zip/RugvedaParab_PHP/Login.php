<?php 
include 'Common.php';
?>
<html>
    <head>
        <title>Login Page</title>
        <link rel="stylesheet" href="login.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>    
    </head>

    <body>

	<?php include 'header.php';?>	
	
        <center>
        <div class="container" id="pan">
            <div class="panel panel-primary">
                <div class="panel-head">
                    
                </div>    
                <div class="panel-body">
                   <p class="text-warning"> Login to make purchase </p> 
                   <form method="Post" action="Login_submit.php">
                       <center>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-4 col-lg-offset-4 ">    
                                        <input type="email" name="email" class="form-control" placeholder="Enter Email-id">    
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-lg-4 col-lg-offset-4 ">     
                                        <input type="password" name="passwd" class="form-control" placeholder="Enter Password">    
                                    </div>
                                </div> 
                            </div>

                            <div class="btn btn-primary">
                                <span name="login">Login</span>
                            </div>
                        </center>    
                   </form>
                </div>
                <div class="panel-footer">
                        <a href="signup.html">Don't have an account? Register</a>
                </div>

            </div>
        </div>
        </center>
    </body>

</html>
<?php 
    include 'footer.php';
?>