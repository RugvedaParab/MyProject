<?php
    require 'Common.php';
    if (isset($_SESSION['email'])) {
        header('location: products.php');
    }
?>
<?php 
    include 'header.php';
?>
<?php 
    include 'footer.php';
?>